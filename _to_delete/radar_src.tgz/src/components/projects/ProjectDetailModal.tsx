import React from 'react';
import { MiningProject } from '../../types/project';
import { Badge } from '../common/Badge';
import { ProjectSatelliteView } from './ProjectSatelliteView';
import { Actor } from '../../types/company';
import { CommercialOpportunity } from '../../types/opportunity';
import { ClientBrand } from '../brand/ICSeal';
import { dossierPdfService } from '../../services/dossierPdfService';
import {
  X,
  ExternalLink,
  MapPin,
  Calendar,
  DollarSign,
  TrendingUp,
  Layers,
  Building2,
  Clock,
  ShieldCheck,
  FileText,
  AlertCircle,
  Sparkles,
  Printer
} from 'lucide-react';

interface ProjectDetailModalProps {
  project: MiningProject | null;
  onClose: () => void;
  onSelectCompanyByName?: (name: string) => void;
  onGenerateBrief?: (project: MiningProject) => void;
  actors?: Actor[];
  opportunities?: CommercialOpportunity[];
  brand?: ClientBrand;
}

export const ProjectDetailModal: React.FC<ProjectDetailModalProps> = ({
  project,
  onClose,
  onSelectCompanyByName,
  onGenerateBrief,
  actors = [],
  opportunities = [],
  brand,
}) => {
  if (!project) return null;

  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-950 border border-slate-800 rounded-[16px] w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="relative px-6 py-6 border-b border-slate-800 flex items-start justify-between gap-6 bg-slate-900 ic-dot-grid">
          <span className="absolute left-0 top-0 bottom-0 w-[3px] bg-amber-400" />
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="ic-rule" />
              <span className="ic-eyebrow text-[10px] text-amber-400">Ficha de proyecto · {project.region}</span>
            </div>
            <h2 className="ic-display text-white text-[26px] sm:text-[30px] mt-3">
              {project.name}<span className="text-amber-400">.</span>
            </h2>
            <div className="mt-3 flex items-center gap-1.5 text-xs text-slate-300">
              <Building2 className="w-3.5 h-3.5 text-amber-400" strokeWidth={1.5} />
              <span>{project.ownerCompany}</span>
              {project.associatedCompanies && project.associatedCompanies.length > 0 && (
                <span className="text-slate-500">(Socios: {project.associatedCompanies.join(', ')})</span>
              )}
            </div>
            <div className="mt-3 flex items-center gap-1.5 flex-wrap">
              <span className="ic-eyebrow text-[9px] px-2 py-1 rounded-[4px] bg-amber-400 text-slate-950">{project.mainMineral}</span>
              {project.submissionType && project.submissionType !== 'No informado' && (
                <span className="ic-mono text-[10px] font-bold px-2 py-0.5 rounded-[4px] border border-slate-700 text-white">{project.submissionType}</span>
              )}
              <span className="text-[11px] text-slate-400 px-1">{project.currentStatus}</span>
              {project.seiaId && (
                <a
                  href={`https://seia.sea.gob.cl/expediente/expediente.php?id_expediente=${project.seiaId}&modo=ficha`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-[4px] bg-white text-slate-950 hover:bg-amber-400 transition"
                >
                  <ExternalLink className="w-3 h-3" /> Expediente SEIA {project.seiaId}
                </a>
              )}
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Métricas Principales (CAPEX, Fechas, Capacidad) */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-500 block">
                CAPEX Estimado
              </span>
              <span className="ic-display text-[24px] text-amber-400 mt-2 block leading-none">
                US${project.capexEstimatedMillionsUSD.toLocaleString('es-CL')} MM
              </span>
              <span className="text-[10px] text-slate-400">Inversión Total</span>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-500 block">
                Etapa de Desarrollo
              </span>
              <span className="text-xs font-bold text-cyan-300 font-mono mt-1 block leading-tight">
                {project.stage}
              </span>
              <span className="text-[10px] text-slate-400">Clasificación 1-14</span>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-500 block">
                Puesta en Marcha Estimada
              </span>
              <span className="text-sm font-bold text-white font-mono mt-1 block">
                {project.estimatedCommissioningDate || 'Por definir'}
              </span>
              <span className="text-[10px] text-slate-400">Inicio: {project.estimatedStartDate || 'N/D'}</span>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-500 block">
                Señales Registradas
              </span>
              <span className="text-xl font-extrabold text-amber-400 font-mono mt-1 block">
                {project.signalsCount}
              </span>
              <span className="text-[10px] text-slate-400">Última: {project.lastUpdateDate}</span>
            </div>
          </div>

          {/* Detalles Operacionales y Capacidad */}
          <div className="p-4 rounded-xl bg-slate-950/50 border border-slate-800 space-y-2 text-xs">
            <div className="flex items-center gap-2 text-slate-300">
              <MapPin className="w-4 h-4 text-amber-400 shrink-0" />
              <span><strong>Ubicación Geográfica:</strong> {project.locationDetails} (Coord: {project.latitude}, {project.longitude})</span>
            </div>
            {project.productiveCapacity && (
              <div className="flex items-center gap-2 text-slate-300">
                <TrendingUp className="w-4 h-4 text-cyan-400 shrink-0" />
                <span><strong>Capacidad Productiva Prevista:</strong> {project.productiveCapacity}</span>
              </div>
            )}
            <div className="flex items-center gap-2 text-slate-300">
              <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                <strong>Fuentes:</strong> {project.informationSources.join(' · ')}
              </span>
            </div>
          </div>

          {/* Vista Satelital de la Faena / Monitoreo Aéreo */}
          <ProjectSatelliteView project={project} />

          {/* Ecosistema Involucrado (EPCM, Contratistas) */}
          <div className="p-4 rounded-xl bg-slate-950/50 border border-slate-800 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-amber-400" />
              <span>Ecosistema de Ejecución & Proveedores Principales</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-slate-500 block">
                  Firma EPCM / Ingeniería Líder
                </span>
                <span className="text-sm font-bold text-amber-300 block mt-1">
                  {project.epcmCompany || 'No designada formalmente / En licitación'}
                </span>
              </div>

              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-slate-500 block">
                  Contratistas y Consultores Clave
                </span>
                <div className="mt-1 flex flex-wrap gap-1">
                  {project.keyContractors && project.keyContractors.length > 0 ? (
                    project.keyContractors.map((c, idx) => (
                      <span
                        key={idx}
                        className="text-[11px] px-2 py-0.5 rounded bg-slate-800 text-slate-200 border border-slate-700"
                      >
                        {c}
                      </span>
                    ))
                  ) : (
                    <span className="text-slate-500 italic">En proceso de licitación</span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Historial de Evolución Inmutable (Requisito crítico del prompt 5) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-cyan-400" />
                  <span>Historial de Evolución & Trazabilidad Inmutable</span>
                </h3>
                <p className="text-[11px] text-slate-500">
                  Cada hito preserva su registro histórico sin sobrescribirse (Línea de tiempo auditable)
                </p>
              </div>
              <span className="text-[10px] font-mono text-amber-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-700">
                {project.history?.length || 0} eventos registrados
              </span>
            </div>

            <div className="relative pl-6 space-y-4 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-800">
              {project.history?.map((entry) => (
                <div key={entry.id} className="relative group">
                  {/* Timeline dot */}
                  <div className="absolute -left-6 top-1.5 w-3 h-3 rounded-full bg-cyan-500 border-2 border-slate-900 group-hover:scale-125 transition-transform" />

                  <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800/80 hover:border-cyan-500/40 transition space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-white text-sm">
                        {entry.signalTitle}
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[10px] text-slate-400">
                          {entry.date}
                        </span>
                        <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 px-1.5 py-0.5 rounded border border-cyan-800/40">
                          {entry.source}
                        </span>
                      </div>
                    </div>

                    {/* Stage & Capex Deltas */}
                    {(entry.previousStage || entry.previousCapex) && (
                      <div className="flex items-center gap-3 text-[11px] p-2 rounded-lg bg-slate-900/90 font-mono">
                        {entry.previousStage && entry.newStage && (
                          <span className="text-slate-300">
                            Etapa: <s className="text-slate-500">{entry.previousStage}</s> → <strong className="text-amber-400">{entry.newStage}</strong>
                          </span>
                        )}
                        {entry.previousCapex && entry.newCapex && (
                          <span className="text-slate-300">
                            CAPEX: <s className="text-slate-500">US$ {entry.previousCapex}M</s> → <strong className="text-amber-400">US$ {entry.newCapex}M</strong>
                          </span>
                        )}
                      </div>
                    )}

                    <p className="text-xs text-slate-300 leading-relaxed">
                      {entry.changeDescription}
                    </p>

                    <div className="p-2.5 rounded-lg bg-amber-950/20 border border-amber-500/20 text-xs">
                      <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wide block mb-0.5">
                        Interpretación Comercial del Cambio:
                      </span>
                      <p className="text-slate-300 text-[11px]">
                        {entry.commercialInterpretation}
                      </p>
                    </div>

                    {entry.potentialImpact && (
                      <div className="text-[11px] text-slate-400">
                        <strong className="text-slate-300">Impacto Potencial:</strong> {entry.potentialImpact}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 flex items-center justify-between bg-slate-950/80">
          <span className="text-xs text-slate-500">
            Última actualización sincronizada: {project.lastUpdateDate}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => dossierPdfService.exportProjectDossier(project, actors, opportunities, brand)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border border-amber-400/50 bg-amber-400/10 hover:bg-amber-400/20 text-amber-300 transition"
              title="Generar y descargar Dossier Ejecutivo en PDF listo para imprimir o presentar"
            >
              <Printer size={13} /> Dossier PDF
            </button>
            {onGenerateBrief && (
              <button
                onClick={() => onGenerateBrief(project)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 transition"
              >
                <Sparkles size={13} /> Brief comercial con IA
              </button>
            )}
            <button
              onClick={onClose}
              className="px-5 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 transition"
            >
              Cerrar Ficha
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
